/**
 * MyLamp
 * @constructor
 */
 function MyLamp(scene, slices, stacks) {
 	CGFobject.call(this, scene);
	
	this.slices = slices;
	this.stacks = stacks;

 	this.initBuffers();
 };

 MyLamp.prototype = Object.create(CGFobject.prototype);
 MyLamp.prototype.constructor = MyLamp;

 MyLamp.prototype.initBuffers = function() {

 	this.vertices = [];

 	this.indices = [];

 	this.normals = [];

	angle = 2*Math.PI / this.slices;
	dinc = (Math.PI / 2) / this.stacks;
	
	for (i = 0, j = 0; i < this.slices; i++)
	{	
		
		for (k = 0.0, d = 0.0; k < 1.0; k += 1.0/this.stacks, j += 4, d += dinc)
		{
			f = Math.cos(d);
			fn = Math.cos(d + dinc);
			console.log(d);
			this.vertices.push(	Math.cos(i*angle)*f, Math.sin(i*angle)*f, k);
			this.normals.push(	Math.cos(i*angle)*f, Math.sin(i*angle)*f, k);

			this.vertices.push(	Math.cos(i*angle)*fn, Math.sin(i*angle)*fn, k+1.0/this.stacks);
			this.normals.push(	Math.cos(i*angle)*fn, Math.sin(i*angle)*fn, k+1.0/this.stacks);

			this.vertices.push(	Math.cos((i+1)*angle)*f, Math.sin((i+1)*angle)*f, k);
			this.normals.push(	Math.cos((i+1)*angle)*f, Math.sin((i+1)*angle)*f, k);

			this.vertices.push(	Math.cos((i+1)*angle)*fn, Math.sin((i+1)*angle)*fn, k+1.0/this.stacks);
			this.normals.push(	Math.cos((i+1)*angle)*fn, Math.sin((i+1)*angle)*fn, k+1.0/this.stacks);

			this.indices.push(j + 1, j, j + 3);
			this.indices.push(j + 2, j + 3, j);
		}
	}
	
 	this.primitiveType = this.scene.gl.TRIANGLES;
 	this.initGLBuffers();
 };
