/**
 * MyInterface
 * @constructor
 */
 
 
function MyInterface() 
{
	CGFinterface.call(this);
};

MyInterface.prototype = Object.create(CGFinterface.prototype);
MyInterface.prototype.constructor = MyInterface;

/**
 * init
 * @param {CGFapplication} application
 */
MyInterface.prototype.init = function(application) 
{
	CGFinterface.prototype.init.call(this, application);
	
	this.gui = new dat.GUI();
	
	var group=this.gui.addFolder("Lights");
	group.open();
	group.add(this.scene, 'Light_0');
	group.add(this.scene, 'Light_1');
	group.add(this.scene, 'Light_2');
	group.add(this.scene, 'Light_3');

	this.gui.add(this.scene, 'Stop_Clock');	

	this.gui.add(this.scene, 'Speed', 0, 0.2);

	this.gui.add(this.scene, 'submarineAppearanceGUI', this.scene.submarineAppearancesList);

	return true;
};

/**
 * processKeyboard
 * @param event {Event}
 */
MyInterface.prototype.processKeyboard = function(event) 
{
	CGFinterface.prototype.processKeyboard.call(this,event);
	switch (event.keyCode)
	{
		case (87): case (119):	//W w
			this.scene.submarine.move('FORWARD', this.scene.Speed);
			break;
		case (65):	case (97):	//A a
			this.scene.submarine.move('R_LEFT', this.scene.Speed);
			break;
		case (83): case (115):	//S s
			this.scene.submarine.move('BACKWARD', this.scene.Speed);
			break;
		case (68): case (100):	//D d
			this.scene.submarine.move('R_RIGHT', this.scene.Speed);
			break;
		default: break;
	};
};